# -*- coding: utf-8 -*-
"""
Created on Tue Aug 21 10:17:41 2018

@author: a.mohammadi
"""
import spacy, re
from spacy.tokens import Doc, Span
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pyodbc, pandas as pd

#%%
def GenerateCountries():
    with pyodbc.connect(connectionParams('AMESYD03','AMEDirect')) as connection:
        query = f"""select [CtryID], [CtryNm], [ISOCountryCode]
                    from [SafeEc].[dbo].[Country]
                    where [CtryNm] not like '%other%'
                    and [CtryNm] not like '%country%'"""
        df_ = pd.read_sql(query, connection)
        
        query = f"""select [CtryID], [AlternativeName] CtryNm
                        from [SafeEc].[dbo].[CountryAlternativeNames]
                        where [Description] like '%english%' 
                        and [Description] not like '%former%' 
                        and [Description] not like '%historic%'
                        and [Description] not like '%unofficial%' """
        df = pd.read_sql(query, connection)
    
    dfc = df_[['CtryID', 'ISOCountryCode']]
    dfc.columns = ['CtryID', 'CtryNm']    

    df = df.append( df_[['CtryID', 'CtryNm']] )
    df = df.append( dfc )
    df = df.fillna('')
    df = df[ df['CtryNm']!='' ]
    df = df.drop_duplicates()
    
    df = df.merge(df_, how='left', on='CtryID')
    df.columns = ['CtryID', 'AlternativeName', 'CtryNm', 'ISOCountryCode']  
    df = df.drop('ISOCountryCode', axis=1)
    df = df[['CtryID', 'CtryNm', 'AlternativeName']]    
    
    countriesIDNm = {}
    for ctrid, cn, an in df.values:
        anl = countriesIDNm.get(ctrid, set())
        anl.add( an )
        countriesIDNm[ctrid] = anl
    
    countriesIDNm = {ctrid: list(anl) for ctrid, anl in countriesIDNm.items()} 
 
    return countriesIDNm
    
#def GenerateCountries():
#    df = pd.read_csv(r'.\AMESpacyPipeline\CountryNameLookupTable.csv', encoding='utf-8-sig').dropna()
#    #countries = {cid: an for cid, cn, an in df.values}
#    countriesIDNm = {}
#    for ctrid, cn, an in df.values:
#        anl = countriesIDNm.get(ctrid, set())
#        anl.add( an )
#        countriesIDNm[ctrid] = anl
#    
#    countriesIDNm = {ctrid: list(anl) for ctrid, anl in countriesIDNm.items()} 
#    
#    return countriesIDNm
    
#%%
def connectionParams(server, database):
    return ''.join([r'DRIVER={ODBC Driver 13 for SQL Server};',
                    r'Trusted_Connection=yes;',
                    r'SERVER=%s;' %server, 
                    r'DATABASE=%s;' %database,])
     
#%%
def GenerateCommodities():      
    with pyodbc.connect(connectionParams('AMESYD03','AMEDirect')) as connection: 
        query = f"""select [CommID], [CommCode], [CommName] 
                    from [Ajax].[Commodity]"""
        df = pd.read_sql(query, connection)
        
    comms = []
    for CommID, CommCode, CommName in df.values:
        # Non valid codes
        if CommCode in ['St', 'Al', 'PGM', 'U', 'PE', 'CL', 'Bx', 'Bu', 'ATH',
                        'SUB', 'CE', 'IO', 'SA', 'SUA', 'V', 'COND', 'Ref Prod',
                        'SD', 'PL', 'Eco', 'FRT', 'EP', 'CPS', 'IP', 'OG', 'SH',
                        'AD', 'C2', 'CR', 'UC', 'ELEC', 'S', 'Ala']:
            CommCode = CommName
            
        comms.append( (CommID, CommCode, CommName.lower())  )
            
    comms.extend([(18, 'Aluminum', 'aluminum'),
#                  (51, 'THM', 'coal'),
                  (54, 'SSCC', 'semisoft'),
                  (54, 'SSCC', 'hvpci'),
                  (77, 'SUA', 'sulfur'),
                  (27, 'H2SO4', 'sulphuric'),
                  (35, 'HBI', 'dri'),
                  (15, 'Fe', 'iron'),
                  ])
    
    commoditiesIDNm = {}
    commoditiesIDCode = {}
    for commid, commcode, commname in comms:
        commoditiesIDCode[commid] = commcode
        
        commL = commoditiesIDNm.get(commid, [])
        commL.append( commname )
        commoditiesIDNm[commid] = commL
            
    return commoditiesIDNm, commoditiesIDCode

#%%
def GenerateSites( commoditiesIDCode ):
    with pyodbc.connect(connectionParams('AMESYD03','AMEDirect')) as connection: 
        query = f"""select [CtryNm], [ISOCountryCode] from [SafeEc].[dbo].[Country]
                        where isnull(ISOCountryCode, '')<>'' """
        df = pd.read_sql(query, connection)
        stopwords = list(df['CtryNm'])
        stopwords.extend(list(df['ISOCountryCode']))
        stopwords.extend([commCode for commID, commCode in commoditiesIDCode.items()])
        stopwords.extend(['SATELLITE', 'USA', 'Closed', 'FeNi', 'SXEW', '[0-9]+',
                          'CLOSED', ])
        
        query = f"""select [SiteID], [SiteNm], [ChartName], [PrimeCommID] from [Ajax].[Site]
                        where [SiteNm] not like '%other%' """
        df = pd.read_sql(query, connection)
    
    pat = ' - .*|Project|project|Joint Venture|J.V.|(I, II,III & IV)|Rio Tinto'
    df['SiteNm'] = df['SiteNm'].str.replace(pat, '')        
    df['ChartName'] = df['ChartName'].str.replace(pat, '')        

    sites = []
    for siteID, siteNm, chartName, primeCommID in df.values:
        for sw in stopwords:
            for match in re.findall(f'\({sw}\)', siteNm):
                siteNm = siteNm.replace(match, '').strip()
        sites.append( (siteID, siteNm, primeCommID) )  
    
    chartes = []
    for siteID, siteNm, chartName, primeCommID in df.values:
        if not chartName: continue
        for sw in stopwords:
            for match in re.findall(f'\({sw}\)', chartName):
                chartName = chartName.replace(match, '').strip()
                
        chartes.append( (siteID, chartName, primeCommID) )  

    for s in chartes:
        if s not in sites:
            sites.append(s)
            
    ext = []
    for siteID, siteNm, primeCommID in sites:
        matches = re.findall('\([^\(\)]+\)', siteNm)
        for match in matches:
            ext.append( (siteID, siteNm.replace(match,''), primeCommID) )
            match = match.strip('(').strip(')')
            ext.append( (siteID, match, primeCommID) )
            ext.append( (siteID,  f"{match} {siteNm[siteNm.index(')')+1:]}", primeCommID ) )
        if '/' in siteNm:
            ext.append( (siteID, siteNm[:siteNm.find('/')], primeCommID) )
            ext.append( (siteID, siteNm[siteNm.find('/')+1:], primeCommID) )
            
    sites.extend(ext)
    
    siteNameList = set()
    for siteID, siteNm, primeCommID in sites:
        siteNm = ' '.join( [snm for snm in siteNm.split(' ') if snm] )
        if len(siteNm)<3 or siteNm.isnumeric(): 
#            print(siteID, siteNm, primeCommID)
            continue
        siteNameList.add( (siteID, siteNm, primeCommID) )
    siteNameList = sorted( list(siteNameList) )     

    sitesIDNm = {SiteID:SiteNm for SiteID, SiteNm, PrimeCommID in sites }
    return sitesIDNm

#%%
def GenerateSiteCommodities():
    with pyodbc.connect( connectionParams('AMESYD03','AMEDirect') ) as connection: 
        query = f"""SELECT [SiteID], [CommID] FROM [AMEDirect].[Ajax].[SiteCommodity]"""
        df = pd.read_sql(query, connection)
        
    siteCommodity = {}
    for SiteID, CommID in df.values:
        commSet = siteCommodity.get( SiteID, set() )
        commSet.add( CommID )
        siteCommodity[SiteID] = commSet
    
    return siteCommodity
        
#%%
def GenerateCompanies():
    with pyodbc.connect( connectionParams('AMESYD03','SafeEc') ) as connection: 
        query = f"""SELECT [CoNm], [CoID]  FROM [Company]
                        where conm not like '%government%' 
                         and conm not like '%private%' 
                         and conm not like '(%)'"""
        df = pd.read_sql(query, connection)
    
    companiesIDNm = {cid:cnm for cnm, cid in df.values} 
    
    return companiesIDNm


#%%
class AMEComponent(object): # self=AMEComponent()
    name = 'AMEComponent'
   
    def __init__(self):
        
        ########## countries
        self.countriesIDNm = GenerateCountries()
        ctrPat = ''    
        for ctrid, anl in self.countriesIDNm.items():
            anlpat = '\W|\W'.join(anl)
            ctrPat = ctrPat + f"|(?P<c{ctrid}>\\W{anlpat}\\W)" 
        ctrPat = ctrPat.strip('|')
        
        self.ctrPatCompiled = re.compile( ctrPat )
        Span.set_extension('countries', getter=self.Countries, force=True)
        Doc.set_extension('countries', default=None, force=True)

        ########## Commodities
        self.commoditiesIDNm, self.commoditiesIDCode = GenerateCommodities()     
        comPat = ''    
        for commid, names in self.commoditiesIDNm.items():
            namespat = '\W|\W'.join(names)
            comPat = comPat + f"|(?P<com{commid}>\\W{namespat}\\W)" 
        comPat = comPat.strip('|')
        
        comCodePat = ''    
        for commid, commcode in self.commoditiesIDCode.items():
            comCodePat = comCodePat + f"|(?P<com{commid}>\\W{commcode}\\W)" 
        comCodePat = comCodePat.strip('|')   

        self.comCodePatCompiled = re.compile(comCodePat)
        self.comPatCompiled = re.compile(comPat, re.I)
        Span.set_extension('commodities', getter=self.Commodities, force=True)
        Doc.set_extension('commodities', default=None, force=True)
        
        ########## sites
        self.sitesIDNm = GenerateSites( self.commoditiesIDCode )
        self.siteNms = list( self.sitesIDNm.values() )
        self.siteIDs = list( self.sitesIDNm.keys() )
        
        vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(2,5), 
                             encoding='utf-8-sig', lowercase=False )
        self.modelChar = vectorizer.fit( self.siteNms )
        vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,4), 
                             encoding='utf-8-sig', lowercase=False )
        self.modelWord = vectorizer.fit( self.siteNms )
        self.sitesTFChar = self.modelChar.transform( self.siteNms )
        self.sitesTFWord = self.modelWord.transform( self.siteNms )
        
        Span.set_extension('sites', getter=self.Sites, force=True)
        Doc.set_extension('sites', default=None, force=True)
        
        ########## companies
        self.companiesIDNm = GenerateCompanies()
        self.companiesNm = list( self.companiesIDNm.values() )
        self.companiesID = list( self.companiesIDNm.keys() )

        vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(2,5), 
                                     encoding='utf-8-sig', lowercase=False )
        self.modelCharCompanies = vectorizer.fit( self.companiesNm )
        vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,4), 
                                     encoding='utf-8-sig', lowercase=False )
        self.modelWordCompanies = vectorizer.fit( self.companiesNm )
        self.CompaniesTFChar = self.modelCharCompanies.transform( self.companiesNm )
        self.CompaniesTFWord = self.modelWordCompanies.transform( self.companiesNm )
        
        Span.set_extension('companies', getter=self.Companies, force=True)
        Doc.set_extension('companies', default=None, force=True)
        
        ##########
    def Companies(self, span):
        text = [' '+span.text+' ',]
        ncTF = self.modelWordCompanies.transform( text )
        cossim = cosine_similarity(self.CompaniesTFWord, ncTF)
        simsWord = cossim.max()
        argsWord = cossim.argmax()
        
        ncTF = self.modelCharCompanies.transform( [span.text,] )
        cossim = cosine_similarity(self.CompaniesTFChar, ncTF)
        simsChar = cossim.max()
        argsChar = cossim.argmax()
        sim = simsWord * simsChar
        
        if sim < 0.4:
            return []
        if simsWord >= simsChar:
            args = argsWord
        elif simsChar >= simsWord:
            args = argsChar
        else:
            return None
            
        cid = self.companiesID[ args ]
#        cnm = self.companiesNm[ args ]
        return [cid,]
    
    def Sites(self, span):
        text = [' '+span.text+' ',]
        ncTF = self.modelWord.transform( text )
        cossim = cosine_similarity(self.sitesTFWord, ncTF)
        simsWord = cossim.max()
        argsWord = cossim.argmax()
        
        ncTF = self.modelChar.transform( [span.text,] )
        cossim = cosine_similarity(self.sitesTFChar, ncTF)
        simsChar = cossim.max()
        argsChar = cossim.argmax()
        sim = simsWord * simsChar
        
        if sim < 0.4:
            return []
        if simsWord >= simsChar:
            args = argsWord
        elif simsChar >= simsWord:
            args = argsChar
        else:
            return None
            
        sid = self.siteIDs[ args ]
#        snm = self.siteNms[ args ]
        return [sid,]

    def Commodities(self, span):
        string = ' ' + span.text + ' '
        commodities = []
        for match in self.comPatCompiled.finditer( string ):
            commodities.append( int( match.lastgroup[3:] ) )
        for match in self.comCodePatCompiled.finditer( string ):
            commodities.append( int( match.lastgroup[3:] ) )
        return commodities

    def Countries(self, span):
        string = ' ' + span.text + ' '        
        coutries = []
        for match in self.ctrPatCompiled.finditer( string ):
            coutries.append( int( match.lastgroup[1:] ) )
        return coutries
       
    def GetSpans(self, doc):
        if not len(doc):
            return []
        #for tok in doc: print(tok, tok.dep_, tok.pos_, tok.like_num, tok.lemma_, tok.shape_)

        chunks = list(doc.noun_chunks) + list(doc.ents) 
        for tok in doc: 
            if tok.like_num or tok.shape_.lower() in ['ddddxd', 'ddddxd', 'xxddxd']: 
#           tok.pos_ in ['PROPN']:
                chunks.append( Span(doc, tok.i, tok.i+1) )

        nces = sorted([ [nc.start, nc.end, nc] 
                        for nc in chunks if nc.text.strip() ])    
        if not len(nces):    
            return [Span(doc, 0, len(doc)),]
        
        spans = []
        start, end, span = nces[0]
        for start, end, nc in nces:        
            if span.end < start:
                spans.append(span)
                span = nc
            else:
                span = Span(doc, min(span.start, start), max(span.end, end) )
        if span not in spans:
            spans.append(span)   
        
        return spans

    def __call__(self, doc):
        doc.user_data['spans'] = self.GetSpans(doc)
        countries, sites, commodities, companies = ([] for i in range(4))
        for span in doc.user_data['spans']:
#            span = doc.user_data['spans'][9]
            countries.extend(span._.countries)
            sites.extend(span._.sites)
            commodities.extend(span._.commodities)
            companies.extend(span._.companies)
            
        doc._.countries = countries
        doc._.sites = sites
        doc._.commodities = commodities
        doc._.companies = companies
       
        return doc  

#%%
def GetNLP():
    
    nlp = spacy.load('en_core_web_sm') 
    AMEComp = AMEComponent()
    nlp.add_pipe( AMEComp ) 
    
    return nlp
    
#%%
if __name__=="__main__":
    nlp = GetNLP()
    
    text = """Hartley platinum project, Zimbabwe; Hot Briquetted Iron plant, 
              Yandi iron ore mine expansion and Beenup titanium minerals project, 
              Western Australia; Cannington silver, lead, zinc project and 
              Crinum coking coal mine, Queensland, Australia; 
              Mt Owen thermal coal development, New South Wales, Australia; 
              and Samarco pellet plant expansion, Brazil. 
              The Northwest Territories Diamonds project in Canada is subject to 
              a number of approvals."""
              
    doc = nlp(text)

    print( doc.user_data['spans'] )

    AMEComp = nlp.pipeline[-1][1]
    print( [AMEComp.countriesIDNm[ctrid] for ctrid in doc._.countries] )
    print( [AMEComp.commoditiesIDNm[commid] for commid in doc._.commodities] )
    print( [AMEComp.sitesIDNm[sid] for sid in doc._.sites] )
    print( [AMEComp.companiesIDNm[cid] for cid in doc._.companies] )

