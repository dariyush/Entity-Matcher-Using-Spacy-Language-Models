# AMENLP

For installation:
	> cd path_to_the_directory_including_setup.py
	> pip install . --user
	
Examples:
	import AMENLP
	
	nlp = AMENLP.GetNLP()
	text = """Hartley platinum project, Zimbabwe; Hot Briquetted Iron plant, 
              Yandi iron ore mine expansion and Beenup titanium minerals project, 
              Western Australia; Cannington silver, lead, zinc project and 
              Crinum coking coal mine, Queensland, Australia; 
              Mt Owen thermal coal development, New South Wales, Australia; 
              and Samarco pellet plant expansion, Brazil. 
              The Northwest Territories Diamonds project in Canada is subject to 
              a number of approvals."""
			  
    doc = nlp(text)

    print( doc.user_data['spans'] )

    AMEComp = nlp.pipeline[-1][1]
    print( [AMEComp.countriesIDNm[ctrid] for ctrid in doc._.countries] )
    print( [AMEComp.commoditiesIDNm[commid] for commid in doc._.commodities] )
    print( [AMEComp.sitesIDNm[sid] for sid in doc._.sites] )
    print( [AMEComp.companiesIDNm[cid] for cid in doc._.companies] )
